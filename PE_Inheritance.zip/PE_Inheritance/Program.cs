﻿using System;

//Beau Wacker
//IGME 105 - Ann Warren
//PE Inheritance - 11/15/2021

namespace PE_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            //introduction
            Console.WriteLine("Welcome to the adventure! " +
                              "Your party of a WARRIOR, a WIZARD, and a THIEF " +
                              "have FIVE DAYS to prepare for your adventure!" +
                              "\nFirst, please make your party!");

            //makeCharacter method to make myWarrior, myWizard, and myThief
            string[] warriorArray = Config.makeCharacter("Warrior");
            string[] wizardArray = Config.makeCharacter("Wizard");
            string[] thiefArray = Config.makeCharacter("Thief");

            Warrior myWarrior = new Warrior(warriorArray[0],
                                            Convert.ToInt32(warriorArray[1]),
                                            Convert.ToInt32(warriorArray[2]),
                                            Convert.ToInt32(warriorArray[3]));

            Wizard myWizard = new Wizard(wizardArray[0],
                                         Convert.ToInt32(wizardArray[1]),
                                         Convert.ToInt32(wizardArray[2]),
                                         Convert.ToInt32(wizardArray[3]));

            Thief myThief = new Thief(thiefArray[0],
                                      Convert.ToInt32(thiefArray[1]),
                                      Convert.ToInt32(thiefArray[2]),
                                      Convert.ToInt32(thiefArray[3]));

            Console.WriteLine("\nNow that we have our heroes, let's begin!" +
                              "\nEach day, you can choose an action for each hero.");

            for (int i = 1; i < 6; i++)
            {
                //prints day
                Console.WriteLine("\n\n" +
                                  "[DAY " + i + "]" +
                                  "\n\n");
                /*if warrior gone too long without bath, party will kick them out*/
                if (myWarrior.StillHere == true)  
                {
                    Console.WriteLine("What will " + myWarrior.Name + " do?" +
                                  "\n(Train, Bathe, or Study)");
                    myWarrior.warriorAction(Console.ReadLine());
                    myWarrior.MaxDays -= myWarrior.Intelligence / 10;   //maxDays affected by intelligence

                    Console.WriteLine();    //formatting space
                }

                Console.WriteLine("What will " + myWizard.Name + " do?" +  
                                   "\n(Train or Study)");
                myWizard.wizardAction(Console.ReadLine());
                myWizard.BackfirePercent = 1 - (myWizard.Intelligence / 100);   //backfirePercent affected by intelligence

                Console.WriteLine();    //formatting space

                Console.WriteLine("What will " + myThief.Name + " do?" +
                                  "\n(Train or Study)");
                myThief.thiefAction(Console.ReadLine());
                myThief.HeistFailChance = 1 - (myThief.Intelligence / 100); //heistFailChance affected by intelligence


                if (myWarrior.DaysSinceBath >= myWarrior.MaxDays)   //determines if warrior is kicked from party
                {
                    myWarrior.StillHere = false;
                    Console.WriteLine(myWarrior.Name + " has gotten too smelly!" +
                                      " Their friends kick them out!");
                }
                    
                if (myThief.HeistFailChance >= 0.5)     //determines if thief's heistsFailed increases
                {
                    Console.WriteLine(myThief.Name + " fails their daily heist!");
                    myThief.HeistsFailed += 1;
                }
                else
                {
                    Console.WriteLine(myThief.Name + " completes their daily heist!");
                }

                if (myWizard.BackfirePercent >= 0.5)    //uses backfirePercent to determine if spell succeeds
                    Console.WriteLine(myWizard.Name + " tries to cast a spell but fails!");
                else
                    Console.WriteLine(myWizard.Name + " casts a fantastic spell!");
                

                Console.WriteLine("Day " + i + " over!");
                Console.WriteLine("Current statistics: ");

                //prints all character's information
                if (myWarrior.StillHere == true)    //only prints warrior info if warrior is still here
                    myWarrior.toString();
                myWizard.toString();
                myThief.toString();
            }

            Console.WriteLine("Training days are up! The party prepares for adventure!");
            Console.WriteLine("Thanks for playing!");
        }
    }
}
