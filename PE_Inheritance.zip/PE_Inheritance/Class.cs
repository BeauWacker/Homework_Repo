﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Beau Wacker
//IGME 105 - Ann Warren
//PE Inheritance - 11/15/2021
//Character Class (Parent)

namespace PE_Inheritance
{
    class Class
    {
        protected string name;
        protected int strength;
        protected int dexterity;
        protected int intelligence;
        protected int experience;

        public Class()
        {
            name = "Name";
            strength = 0;
            dexterity = 0;
            intelligence = 0;
            experience = 0;
        }

        public Class (string name, int strength, int dexterity, int intelligence)
        {
            this.name = name;
            this.strength = strength;
            this.dexterity = dexterity;
            this.intelligence = intelligence;
        }

        public string Name
        { get { return name; } }

        public int Strength
        { get { return strength; } }

        public int Dexterity
        { get { return dexterity; } }

        public int Intelligence
        { 
            get { return intelligence; } 
            set { intelligence += value; }
        }

        //experience get/set
        public int Experience
        {
            get { return experience; }
            set 
            {
                if (experience + value > 100)
                    experience = 100;
                else if (experience + value < 0)
                    experience = 0;
                else
                    experience += value;
            }
        }

        //print method
        public virtual void toString()
        {
            Console.WriteLine("\nName: " + name +
                              "\nStrength: " + strength +
                              "\nDexterity: " + dexterity +
                              "\nIntelligence: " + intelligence);
        }

        //Parent class for different classes
        //Warrior, Wizard, and Thief are child classes
        //parameterized constructor of strength, dexterity, and intelligence
        //privare name attribute with accessor (can be assumed the name won't change)
        //toString method that returns a string containing the character's information

        //for child classes:
        //all have parameterized constructors for all attributes
        //method to change intelligence value
    }
}
