﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_Inheritance
{
    //Beau Wacker
    //IGME 105 - Ann Warren
    //PE Inheritance - 11/17/2021
    //Warrior class (child of Class)

    class Warrior : Class
    {
        protected int daysSinceBath;
        protected bool stillHere;   //determines if the warrior has been kicked out of the group or not
        protected int maxDays;  //determines the maximum number of days the warrior can go without a bath

        public Warrior (string name, int strength, int dexterity, int intelligence) : 
                        base (name, strength, dexterity, intelligence)
        {
            daysSinceBath = 0;
            stillHere = true;
            maxDays = 3;
        }

        //  get/set
        public int MaxDays
        {
            get { return maxDays; }
            set { maxDays = value; }
        }

        //  get/set
        public int DaysSinceBath
        { get { return daysSinceBath; } }

        //  get/set
        public bool StillHere
        { 
            get { return stillHere; } 
            set { stillHere = value; }
        }

        //print method
        public override void toString()
        {
            Console.WriteLine("\nName: " + name +
                              "\nStrength: " + strength +
                              "\nDexterity: " + dexterity +
                              "\nIntelligence: " + intelligence + 
                              "\nXP: " + experience + 
                              "\nDays since last bath: " + daysSinceBath + "\n");
        }

        public void warriorAction(string action)
        {
            switch (action.ToUpper())
            {
                case "TRAIN":
                    Console.WriteLine(name + " gains 20 XP!");
                    experience += 20;
                    Console.WriteLine(name + " has gone " + daysSinceBath +
                                      " days since taking a bath!" + 
                                      " Their friends seem more upset...");
                    daysSinceBath += 1;
                    break;
                case "BATHE":
                    Console.WriteLine(name + "'s days since last bath now equals zero!" + 
                                      " Their friends seem happier!");
                    daysSinceBath = 0;
                    break;
                case "STUDY":
                    Console.WriteLine(name + "'s INT increases by 2 points!");
                    intelligence += 2;
                    Console.WriteLine(name + " learns how to take better care of your hygeine." +
                                      name + " can now go an extra day without a bath!");
                    daysSinceBath -= 1;
                    break;
                default:
                    Console.WriteLine("Invalid input. You get to do nothing!");
                    Console.WriteLine(name + " has gone " + daysSinceBath +
                                      " days since taking a bath!" +
                                      " Their friends seem more upset...");
                    daysSinceBath += 1;
                    break;
            }
        }
    }
}
