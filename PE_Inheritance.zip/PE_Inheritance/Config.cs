﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_Inheritance
{
    //Beau Wacker
    //IGME 105 - Ann Warren
    //PE Inheritance - 11/17/2021
    //Config class for methods

    class Config
    {
        //method that will prompt for values and return array for character parameters
        public static string[] makeCharacter(string characterType)
        {
            string[] parameters = new string[4];

            Console.WriteLine();    //formatting space

            Console.Write(characterType + "'s name: ");
            parameters[0] = Console.ReadLine();
            Console.Write(characterType + "'s strength: ");
            parameters[1] = Console.ReadLine();
            Console.Write(characterType + "'s dexterity: ");
            parameters[2] = Console.ReadLine();
            Console.Write(characterType + "'s intelligence: ");
            parameters[3] = Console.ReadLine();

            Console.WriteLine();    //formatting space

            return parameters;
        }

        //was planning to add methods to check for valid input but ran out of time
    }
}
