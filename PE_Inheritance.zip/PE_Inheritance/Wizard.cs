﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_Inheritance
{
    //Beau Wacker
    //IGME 105 - Ann Warren
    //PE Inheritance - 11/17/2021
    //Wizard class (child of Class)

    class Wizard : Class
    {

        protected double backfirePercent;
        public Wizard (string name, int strength, int dexterity, int intelligence) : 
                       base (name, strength, dexterity, intelligence)
        {

        }

        //  get/set
        public double BackfirePercent
        {
            get { return backfirePercent; }
            set
            {
                if (backfirePercent + value > 100.0)
                    backfirePercent = 100.0;
                else if (backfirePercent + value < 0.0)
                    backfirePercent = 0.0;
                else
                    backfirePercent += value;
            }
        }

        //print method
        public override void toString()
        {
            Console.WriteLine("\nName: " + name +
                              "\nStrength: " + strength +
                              "\nDexterity: " + dexterity +
                              "\nIntelligence: " + intelligence +
                              "\nXP: " + experience +
                              "\nBackfire chance: " + backfirePercent + "\n");
        }

        public void wizardAction(string action)
        {
            switch (action.ToUpper())
            {
                case "STUDY":
                    Console.WriteLine(name + "'s INT increases by 2 points!");
                    intelligence += 2;
                    break;
                case "TRAIN":
                    Console.WriteLine(name + " gains 20 XP!");
                    experience += 20;
                    Console.WriteLine(name + " is now less likely to mess up their spells!");
                    backfirePercent -= 0.2;
                    break;
                default:
                    Console.WriteLine("Invalid input. You get to do nothing!");
                    break;
            }
        }
    }
}
