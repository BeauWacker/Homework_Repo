﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_Inheritance
{
    //Beau Wacker
    //IGME 105 - Ann Warren
    //PE Inheritance - 11/17/2021
    //Thief class (child of Class)

    class Thief : Class
    {
        protected double heistFailChance;
        protected int heistsFailed;

        public Thief (string name, int strength, int dexterity, int intelligence) : 
                      base (name, strength, dexterity, intelligence)
        {
            heistsFailed = 0;
        }

        //  get/set
        public double HeistFailChance
        {
            get { return heistFailChance; }
            set
            {
                if (heistFailChance + value > 100.0)
                    heistFailChance = 100.0;
                else if (heistFailChance + value < 0.0)
                    heistFailChance = 0.0;
                else
                    heistFailChance += value;
            }
        }

        //  get/set
        public int HeistsFailed
        {
            get { return heistsFailed; }
            set 
            {
                if (heistsFailed + value < 0)
                    heistsFailed = 0;
                else
                    heistsFailed += value;
            }
        }

        //print method
        public override void toString()
        {
            Console.WriteLine("\nName: " + name +
                              "\nStrength: " + strength +
                              "\nDexterity: " + dexterity +
                              "\nIntelligence: " + intelligence +
                              "\nXP: " + experience +
                              "\nHeist failure chance: " + heistFailChance +
                              "\nHeists failed: " + heistsFailed + "\n");
        }

        public void thiefAction(string action)
        {
            switch (action.ToUpper())
            {
                case "STUDY":
                    Console.WriteLine(name + "'s INT increases by 2 points!");
                    intelligence += 2;
                    break;
                case "TRAIN":
                    Console.WriteLine(name + " gains 20 XP!");
                    experience += 20;
                    Console.WriteLine(name + " is better at stealing and will now fail less heists!");
                    heistFailChance -= 0.2;
                    break;
                default:
                    Console.WriteLine("Invalid input. You get to do nothing!");
                    break;
            }
        }
    }
}
