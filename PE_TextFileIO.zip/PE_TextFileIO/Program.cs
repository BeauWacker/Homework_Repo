﻿using System;
using System.IO;

//Beau Wacker
//IGME 105 - Ann Warren
//Text File IO PE
//I have NO IDEA HOW THIS IO STUFF WORKS SEND HELP
//JK I'LL EITHER ASK ON MONDAY OR GO TO OFFICE HOURS OR MAYBE PRAY
//THO I'M ATHIEST SO THAT MIGHT NOT TURN OUT GREAT
// 12/3/2021

namespace PE_TextFileIO
{
    class Program
    {
        static void Main(string[] args)
        {
            string userInput;
            string[] myArray;

            Console.WriteLine("Welcome! Select an option:\n");
            Console.WriteLine("1 - Enter Data" +
                              "2 - Save Data" +
                              "3 - Load Data" +
                              "4 - Print Data" +
                              "5 - Quit");

            myArray = Config.enterData();
            Config.saveData(myArray);
            Config.loadData();

            userInput = Console.ReadLine();

            while (userInput != "1" || userInput != "2" || userInput != "3" ||
                   userInput != "4" || userInput != "5")
            {
                Console.WriteLine("Invalid input, try again: ");
                userInput = Console.ReadLine();
            }

            for (int i = 0; i < 100;)
            {
                switch (userInput)
                {
                    case "1":
                        myArray = Config.enterData();
                        break;
                    case "2":
                        Config.saveData(myArray);
                        break;
                    case "3":
                        //I'm REALLY confused about the text IO stuff
                        //sooo yeah this is all I could figure out the internet wasn't very helpful
                        Config.loadData();
                        break;
                    case "4":
                        Config.printData(myArray);
                        break;
                    case "5":
                        return;
                }
            }
            
        }
    }
}
