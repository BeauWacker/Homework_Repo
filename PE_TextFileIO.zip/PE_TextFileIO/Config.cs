﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

//Beau Wacker
//IGME 105 - Ann Warren
//Text File IO PE
//I have NO IDEA HOW THIS IO STUFF WORKS SEND HELP
//JK I'LL EITHER ASK ON MONDAY OR GO TO OFFICE HOURS OR MAYBE PRAY
//THO I'M ATHIEST SO THAT MIGHT NOT TURN OUT GREAT
// 12/3/2021
//Config class - contains methods

namespace PE_TextFileIO
{
    class Config
    {
        //method for Enter Data user selection
        public static string[] enterData()
        {
            Console.WriteLine();    //formatting space

            string userInput;
            string[] newArray;

            Console.WriteLine("How many players will you add?");

            userInput = Console.ReadLine();
            newArray = new string[Convert.ToInt32(userInput)];

            for (int i = 0; i < Convert.ToInt32(userInput); i++)
            {
                Console.WriteLine("Enter a player's name: ");
                newArray[i] = Console.ReadLine();
            }

            Console.WriteLine();    //formatting space
            return newArray;
        }

        //method for Print Data user selection
        public static void printData(string[] myArray)
        {
            Console.WriteLine();    //formatting space

            Console.WriteLine("Current player list:");

            if (myArray.Length == 0)
            {
                Console.WriteLine("No players in list.");
                return;
            }

            for (int i = 0; i < myArray.Length; i++)
                Console.WriteLine(myArray[i]);
            
            Console.WriteLine();    //formatting space
        }

        //method for Save Data user selection
        public static void saveData(string[] myArray)
        {
            StreamWriter writer = new StreamWriter("TextFileIO.txt");

            if (myArray.Length == 0)
            {
                Console.WriteLine("List of players is empty, nothing to save.");
                return;
            }

            Console.WriteLine("Saving list of players.");

            for (int i = 0; i < myArray.Length; i++)
            {
                writer.WriteLine(myArray[i]);
            }

            Console.WriteLine("File saved.");
            writer.Close();
        }

        //method for Load Data user selection
        public static string loadData()
        {
            StreamReader reader = new StreamReader("TextFileIO.txt");

            string line = reader.ReadLine();
            reader.Close();

            Console.WriteLine(line);
            return line;
        }
    }
}
