﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_ArraysOfObjects
{
    class Card
    {
        private int value;
        private string suit;

        public Card(int value, string suit)
        {

            this.value = value;
            this.suit = suit;

        }

        public int Value
        { get { return value; } }

        public string Suit
        { get { return suit; } }

        public void Print()
        {

            switch (value)
            {
                case 11:
                    Console.WriteLine("Jack of " + suit + "s");
                    break;
                case 12:
                    Console.WriteLine("Queen of " + suit + "s");
                    break;
                case 13:
                    Console.WriteLine("King of " + suit + "s");
                    break;
                case 1:
                    Console.WriteLine("Ace of " + suit + "s");
                    break;
                default:
                    Console.WriteLine((value + 1) + " of " + suit + "s");
                    break;
            }

        }
    }
}
