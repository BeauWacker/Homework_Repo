﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_ArraysOfObjects
{
    class Deck
    {
        private Card[] cards = new Card[52];
        private Random ran = new Random();

        public Deck()
        {
            for (int i = 0; i < 13; i++)
            { cards[i] = new Card(i+1, "Heart"); }

            for (int i = 13; i < 26; i++)
            { cards[i] = new Card(i+1, "Club"); }

            for (int i = 26; i < 39; i++)
            { cards[i] = new Card(i+1, "Diamond"); }

            for (int i = 39; i < 52; i++)
            { cards[i] = new Card(i+1, "Spade"); }

            int randNum = Ran.Next(53);
        }

        public Card[] Cards
        { get { return cards; }  }

        public Random Ran
        { get { return ran; } }

        public void Print()
        {
            for (int i = 0; i < 52; i++)
            {
                switch (cards[i].Suit)
                {
                    case "Heart":
                        Console.WriteLine(Config.checkSpecialValue(cards[i].Value) + " Hearts");
                        break;
                    case "Club":
                        Console.WriteLine(Config.checkSpecialValue(cards[i].Value - 13) + " Clubs");
                        break;
                    case "Diamond":
                        Console.WriteLine(Config.checkSpecialValue(cards[i].Value - 26) + " Diamonds");
                        break;
                    case "Spade":
                        Console.WriteLine(Config.checkSpecialValue(cards[i].Value - 39) + " Spades");
                        break;
                }
            }
                
        }

        public void Deal(int amount, Deck deck)
        {
            for (int i = 0; i < amount; i++)
            {
                int randomNumber = deck.Ran.Next(53);
                cards[randomNumber].Print();
            }
        }
    }
}
