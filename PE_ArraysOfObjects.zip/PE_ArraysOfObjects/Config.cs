﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_ArraysOfObjects
{
    class Config
    {
        public static string checkSpecialValue (int value)
        {
            switch (value)
            {
                case 11:
                    return "Jack of ";
                case 12:
                    return "Queen of ";
                case 13:
                    return "King of ";
                case 1:
                    return "Ace of ";
                default:
                    return value + " of ";
            }
        }
        public static bool checkInt(string num, int min, int max)
        {
            try { int.Parse(num); }
            catch
            {
                Console.WriteLine("Invalid Input. Please enter a positive whole number");
                return false;
            }

            int numIntValue = Convert.ToInt32(num);

            if (numIntValue < min || numIntValue > max)
            {
                Console.WriteLine("Invalid Input. Please enter a positive whole number");
                return false;
            }
            else
            {
                return true;
            }
        }


    }
}
