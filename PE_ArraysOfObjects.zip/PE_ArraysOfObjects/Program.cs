﻿using System;

namespace PE_ArraysOfObjects
{
    class Program
    {
        static void Main(string[] args)
        {
            Deck deck = new Deck();
            int deal;

            Console.WriteLine("Your deck: ");
            deck.Print();

            Console.Write("Enter a whole number of cards to deal (1-52): ");
            string userInput = Console.ReadLine();
            
            while (Config.checkInt(userInput, 1, 52) != true)
            {
                userInput = Console.ReadLine();
            }
            deal = Convert.ToInt32(userInput);

            deck.Deal(deal, deck);
        }
    }
}
