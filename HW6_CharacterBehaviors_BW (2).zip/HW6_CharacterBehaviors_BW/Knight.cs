﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Beau Wacker
//Ann Warren IGME 105
//HW 6 - Character Behaviors
//  11/23/2021

//HW 7 - Refactoring
//THIS PROJECT HAS BEEN REFACTORED FOR HW 7

namespace HW6_CharacterBehaviors_BW
{
    class Knight : CommonCharacter
    {
        private int swordDamage;
        private int shieldProtection;

        public Knight (string name, int health, int strength, int dexterity) :
               base (name, health, strength, dexterity)
        {
            swordDamage = 15;
            shieldProtection = 5;
        }

        public override string ToString()
        {
            string stats = ("Your KNIGHT has a STRENGTH score of " + strength +
                            ", a DEXTERITY score of " + dexterity +
                            ", and a HEALTH score of " + health +
                            "\nThe KNIGHT also posesses a sword that deals " + swordDamage +
                            " damage, and a shield that gives the KNIGHT " + shieldProtection +
                            " points of damage resistance.");
            return stats;
        }

        public override int Attack(Random ran)
        {
            int attack = ran.Next(0, strength + 1) + swordDamage;
            return attack;
        }

        public override void TakeDamage(int damage)
        { 
            health -= (damage - shieldProtection);
            Console.WriteLine("ASSASSIN deals " + damage +
                              " points of damage to the KNIGHT.");
        }

        public override bool HasFled(int assassinHealth)
        {
            if (assassinHealth >= (health + 60))
                return true;
            else
                return false;
        }

        
    }
}
