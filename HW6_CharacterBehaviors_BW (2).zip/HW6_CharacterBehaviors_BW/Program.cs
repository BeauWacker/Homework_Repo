﻿using System;
using System.Collections.Generic;

//Beau Wacker
//Ann Warren IGME 105
//HW 6 - Character Behaviors
//  11/23/2021

//HW 7 - Refactoring
//THIS PROJECT HAS BEEN REFACTORED FOR HW 7

namespace HW6_CharacterBehaviors_BW
{
    class Program
    {
        static void Main(string[] args)
        {

            int damage = 0;
            int round = 0;
            Random ran = new Random();

            Knight redKnight = new Knight("RED KNIGHT", 100, 20, 10);
            Knight blueKnight = new Knight("BLUE KNIGHT", 80, 30, 10);

            Assassin greenAssassin = new Assassin("GREEN ASSASSIN", 70, 10, 25);
            Assassin yellowAssassin = new Assassin("YELLOW ASSASSIN", 60, 20, 25);

            //creates list of all characters and adds the knights and assassins that were already created to it
            List<CommonCharacter> characters = new List<CommonCharacter>();
            characters.Add(redKnight);
            characters.Add(blueKnight);
            characters.Add(greenAssassin);
            characters.Add(yellowAssassin);

            //Beginning of loop, only ends when one character remains
            for (int i = 1; i < 100;)
            {
                //print current round
                round += 1;
                Console.WriteLine("Round " + round + " ------------- ");

                int pickOpponent = ran.Next(0, characters.Count);

                for (int j = 0; (j < characters.Count - 1); j++)
                {
                    damage = characters[j].Attack(ran);

                    while (pickOpponent == j)
                        pickOpponent = ran.Next(0, characters.Count);

                    characters[pickOpponent].TakeDamage(damage);
                }
                
                
                //checks if knight or assassin are dead, ends loop if either are
                for (int k = 0; (k < characters.Count); k++)
                {
                    if (characters[k].isDead() == true)
                    {
                        Console.WriteLine(characters[k].Name + " is dead!");
                        characters.RemoveAt(k);
                    }
                }

                for (int l = 0; l < characters.Count; l++)
                {
                    if (characters[l].HasFled(characters[l].Health) == true)
                    {
                        Console.WriteLine(characters[l].Name + " has fled!");
                        characters.RemoveAt(l);
                    }
                }

                if (characters.Count == 1)
                {
                    i = 101;
                } else if (characters.Count < 1)
                {
                    i = 101;
                }

            }

            Console.WriteLine(characters[0].Name + " WINS!");





            //OLD CODE FROM HW 6

            /* int round = 0;
            int damage = 0;
            Random ran = new Random();

            Knight myKnight = new Knight("Temp", 100, 20, 10);
            Assassin myAssassin = new Assassin("Temp", 70, 10, 25);

            Console.WriteLine("Welcome to the game! The KNIGHT and the ASSASSIN will fight " +
                              "until one has DIED or FLED.");

            Console.WriteLine();    //formatting space
            Console.WriteLine(myKnight.ToString());
            Console.WriteLine();    //formatting space
            Console.WriteLine(myAssassin.ToString());
            Console.WriteLine();    //formatting space

            for (int i = 1; i < 100; )
            {
                //print current round
                round += 1;
                Console.WriteLine("Round " + round + " ------------- ");

                damage = myKnight.Attack(ran);  //sets damage to damage done by knight
                myAssassin.TakeDamage(damage);  //subtracts knight's damage from assassin's health

                damage = myAssassin.Attack(ran);    //sets damage to damage done by assassin
                myKnight.TakeDamage(damage);        //subtracts assassin's damage from knight's health

                Console.WriteLine();    //formatting space
                Console.WriteLine("The KNIGHT has " + myKnight.Health + " HEALTH left.");
                Console.WriteLine("The ASSASSIN has " + myAssassin.Health + " HEALTH left.");
                Console.WriteLine();    //formatting space

                //checks if knight or assassin are dead, ends loop if either are
                if (myKnight.isDead() == true)
                {
                    if (myAssassin.isDead() == true)
                    {
                        Console.WriteLine("The KNIGHT and the ASSASSIN are DEAD! It's a TIE!");
                        return;
                    }
                    Console.WriteLine("The KNIGHT is DEAD. The ASSASSIN WINS!");
                }
                  
                if (myAssassin.isDead() == true)
                {
                    Console.WriteLine("The ASSASSIN is DEAD. The KNIGHT WINS!");
                    return;
                }

                //checks if knight or assassin flee, ends loop if either are
                if (myKnight.HasFled(myAssassin.Health) == true)
                {
                    if (myAssassin.HasFled(myKnight.Health) == true)
                    {
                        Console.WriteLine("The KNIGHT and the ASSASSIN have both FLED. It's a TIE!");
                        return;
                    }
                    Console.WriteLine("The KNIGHT has FLED. The ASSASSIN WINS!");
                    return;
                }
                if (myAssassin.HasFled(myKnight.Health) == true)
                {
                    Console.WriteLine("The ASSASSIN has FLED. The KNIGHT WINS!");
                    return;
                }
            } */
        }
    }
}
