﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Beau Wacker
//Ann Warren IGME 105
//HW 6 - Character Behaviors
//  11/23/2021

//HW 7 - Refactoring
//THIS PROJECT HAS BEEN REFACTORED FOR HW 7

namespace HW6_CharacterBehaviors_BW
{
    class CommonCharacter
    {
        protected int health;
        protected int strength;
        protected int dexterity;
        protected string name;
        
        public CommonCharacter (string name, int health, int strength, int dexterity)
        {
            this.health = health;
            this.strength = strength;
            this.dexterity = dexterity;
            this.name = name;
        }


        public int Health
        { get { return health; } }

        public int Strength
        { get { return strength; } }

        public int Dexterity
        { get { return dexterity; } }

        public string Name
        { get { return name; } }


        public bool isDead()
        {
            if (health <= 0)
                return true;
            else
                return false;
        }

        public virtual string ToString()
        {
            string stats = ("Your " + name + " has a STRENGTH score of " + strength +
                            ", a DEXTERITY score of " + dexterity +
                            ", and a HEALTH score of " + health);
            return stats;
        }

        public virtual void TakeDamage(int damage)
        {
            health -= (damage);
            Console.WriteLine(name + " deals " + damage +
                              " points of damage to their opponent.");
        }

        public virtual int Attack(Random ran)
        {
            int attack = ran.Next(0, dexterity + 1);
            return attack;
        }

        public virtual bool HasFled(int health)
        {
            if (health >= (health + 60))
                return true;
            else
                return false;
        }
    }
}
