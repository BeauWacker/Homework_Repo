﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW6_CharacterBehaviors_BW
{
    class Assassin : CommonCharacter
    {
        private int daggerDamage;
        private int swiftBoots;
        private Random checkHit = new Random();

        public Assassin (int health, int strength, int dexterity) :
               base (health, strength, dexterity)
        {
            //strength, dex, and health will be randomized, but Assassin will have higher dexterity
            daggerDamage = 10;
            swiftBoots = 30;
        }

        public override string ToString()
        {
            string stats = ("Your ASSASSIN has a STRENGTH score of " + strength +
                            ", a DEXTERITY score of " + dexterity +
                            ", and a HEALTH score of " + health +
                            "\nThe ASSASSIN also posesses a DAGGER that deals " + daggerDamage +
                            " damage, and BOOTS OF SWIFTNESS that give the ASSASSIN a " + swiftBoots +
                            "% chance of not being hit.");
            return stats;
        }

        public int Attack(Random ran)
        {
            int attack = ran.Next(0, dexterity + 1) + daggerDamage;
            return attack;
        }

        public void TakeDamage(int damage)
        {
            int chanceHit = checkHit.Next(0, 101);
            if (chanceHit >= swiftBoots)
            {
                health -= damage;
                Console.WriteLine("The KNIGHT deals " + damage +
                                  " points of damage to the ASSASSIN.");
            }
            else
                Console.WriteLine("The ASSASSIN dodges the KNIGHT's the attack!");
        }

        public bool HasFled(int knightHealth)
        {
            if (knightHealth >= (health + 50))
                return true;
            else if (health <= 10)
                return true;
            else
                return false;
        }

        public bool isDead()
        {
            if (health <= 0)
                return true;
            else
                return false;
        }
    }
}
