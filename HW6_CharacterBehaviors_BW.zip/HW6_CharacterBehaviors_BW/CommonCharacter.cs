﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW6_CharacterBehaviors_BW
{
    class CommonCharacter
    {
        protected int health;
        protected int strength;
        protected int dexterity;
        
        public CommonCharacter (int health, int strength, int dexterity)
        {
            this.health = health;
            this.strength = strength;
            this.dexterity = dexterity;
        }

        public int Health
        { get { return health; } }

        public int Strength
        { get { return strength; } }

        public int Dexterity
        { get { return dexterity; } }
    }
}
