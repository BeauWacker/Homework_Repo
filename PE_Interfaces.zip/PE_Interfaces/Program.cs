﻿using System;

//Beau Wacker
//IGME 105 - Ann Warren
//PE Interfaces - Practice exercise based on the game Feudal
// 11/24/2021

namespace PE_Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            King myKing = new King(12, 12);
            myKing.Print();

            myKing.moveX(-2);
            myKing.Print();

            myKing.moveY(1);
            myKing.Print();

            myKing.moveDiagonal(2, "LEFT", "DOWN");
            myKing.Print();

            myKing.isAttacked(true, "Archer");
            myKing.Print();
        }
    }
}
