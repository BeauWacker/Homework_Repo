﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_Interfaces
{
    class King : IPiece
    {
        private int xPos;
        private int yPos;
        private bool isAlive;

        public King (int xPos, int yPos)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            isAlive = true;
        }

        public int XPos
        { 
            get { return xPos; } 
            set { xPos = value; }
        }


        public int YPos
        { 
            get { return yPos; }
            set { yPos = value; }
        }

        public bool IsAlive
        { 
            get { return isAlive; }
            set { isAlive = value; }
        }


        public void moveX(int diff)
        {
            if (diff < 0)
                Console.WriteLine("Moved " + (diff * -1) + " spaces left");
            if (diff > 0)
                Console.WriteLine("Moved " + diff + " spaces right");

            if (diff == 1 || diff == 2 || diff == -1 || diff == -2)
                xPos += diff;
        }

        public void moveY(int diff)
        {
            if (diff < 0)
                Console.WriteLine("Moved " + (diff * -1) + " spaces up");
            if (diff > 0)
                Console.WriteLine("Moved " + diff + " spaces down");

            if (diff == 1 || diff == 2 || diff == -1 || diff == -2)
                yPos += diff;
        }

        public void moveDiagonal(int diff, string LeftOrRight, string UpOrDown)
        {
            if (diff == 1 || diff == 2)
            {
                if (LeftOrRight.ToUpper() == "LEFT")
                {
                    if (UpOrDown.ToUpper() == "UP")
                    {
                        Console.WriteLine("Moved " + diff + " spaces up and " +
                                           diff + " spaces to the left");
                        xPos -= diff;
                        yPos += diff;
                    }
                    else if (UpOrDown.ToUpper() == "DOWN")
                    {
                        Console.WriteLine("Moved " + diff + " spaces down and " +
                                           diff + " spaces to the left");
                        xPos -= diff;
                        yPos -= diff;
                    }
                }
                else if (LeftOrRight.ToUpper() == "RIGHT")
                {
                    if (UpOrDown.ToUpper() == "UP")
                    {
                        Console.WriteLine("Moved " + diff + " spaces up and " +
                                           diff + " spaces to the right");
                        xPos += diff;
                        yPos += diff;
                    }
                    else if (UpOrDown.ToUpper() == "DOWN")
                    {
                        Console.WriteLine("Moved " + diff + " spaces down and " +
                                           diff + " spaces to the right");
                        xPos += diff;
                        yPos -= diff;
                    }
                }
            }
        }

        public void isAttacked(bool attackSuccess, string attacker)
        {
            if (attackSuccess == true)
            {
                Console.WriteLine(attacker + " attacks the king.");
                isAlive = false;
            }
        }

        public void Print()
        {
            Console.WriteLine();    //formatting space
            Console.WriteLine("The King is at position {" +
                               xPos + ", " + yPos + "}");
            if (isAlive == true)
                Console.WriteLine("The King is alive.");
            else
                Console.WriteLine("The King is dead.");
            Console.WriteLine();    //formatting space
        }
    }
}
