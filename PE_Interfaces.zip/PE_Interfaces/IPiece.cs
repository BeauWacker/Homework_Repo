﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PE_Interfaces
{
    public interface IPiece
    {
        void moveX(int diff);
        void moveY(int diff);
        void moveDiagonal(int diff, string LeftOrRight, string UpOrDown);
        void isAttacked(bool attackSuccess, string attacker);

    }
}
